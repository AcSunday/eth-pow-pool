#### System information

Geth version: `geth version` or commit hash if `develop`

Redis version: `redis-server --version`

OS & Version: Linux/OSX

Commit branch and hash: (`master`, `ba60e1c`)

#### Expected behaviour


#### Actual behaviour


#### Steps to reproduce the behaviour


#### Backtrace

````
[backtrace]
````
